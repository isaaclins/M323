/**
 * Doppelte Rekursion
 *
 * @author Daniel Fahrni
 * @version 14.03.2025
 */
public class StarPatternStep2 {
    public static void main(String[] args) {
        printPatternRekursiv(5);
    }

    static void printPatternRekursiv(int n) {
        printPatternRekursivOuterLoop(n, 1);
        //printPatternRekursivOuterLoop2(n);
    }

    static void printPatternRekursivOuterLoop(int n, int i) {
        if (i > n) {
            return;
        }
        for (int j = 1; j <= i; j++) { // Innere Schleife für die Sterne
            System.out.print("*");
        }
        System.out.println(); // Neue Zeile nach jeder Reihe von Sternen
        printPatternRekursivOuterLoop(n, i+1);
    }

    static void printPatternRekursivOuterLoop2(int i) {
        if (i <= 0) {
            return;
        }
        printPatternRekursivOuterLoop2(i-1);
        for (int j = 1; j <= i; j++) { // Innere Schleife für die Sterne
            System.out.print("*");
        }
        System.out.println(); // Neue Zeile nach jeder Reihe von Sternen
    }
}