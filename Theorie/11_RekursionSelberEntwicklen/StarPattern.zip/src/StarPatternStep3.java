/**
 * Doppelte Rekursion
 *
 * @author Daniel Fahrni
 * @version 14.03.2025
 */
public class StarPatternStep3 {
    public static void main(String[] args) {
        printPatternRekursiv(5);
    }

    static void printPatternRekursiv(int n) {
        printPatternRekursiv(n, 1, 1);
    }

    static void printPatternRekursiv(int n, int i, int j) {
        if (i > n) {
            return;
        }
        if (j <= i) {
            System.out.print('*');
            printPatternRekursiv(n, i, j+1);
            return;
        }
        System.out.println();
        printPatternRekursiv(n, i+1, 1);
    }
}