/**
 * Doppelte Rekursion
 *
 * @author Daniel Fahrni
 * @version 14.03.2025
 */
public class StarPatternStep1 {
    public static void main(String[] args) {
        printPatternRekursiv(5);
    }

    static void printPatternRekursiv(int n) {
        printPatternRekursivInnerLoop(n);
    }

    static void printPatternRekursivInnerLoop(int n) {
        for (int i = 1; i <= n; i++) { // Äussere Schleife für die Zeilen
            printStarsRekursiv(i, 1);
            //printStarsRekursiv2(i);
            System.out.println(); // Neue Zeile nach jeder Reihe von Sternen
        }
    }

    static void printStarsRekursiv(int i, int j) {
        if (j <= i) {
            System.out.print('*');
            printStarsRekursiv(i, j+1);
        }
    }

    static void printStarsRekursiv2(int j) {
        if (j <= 0) {
            return;
        }
        System.out.print('*');
        printStarsRekursiv2(j-1);
    }
}